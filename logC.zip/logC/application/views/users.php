<div class="container" style="width: 40%; text-align: center; padding: 50px" >
	<a href="<?php echo base_url().'main/logout'; ?>" class="btn btn-success btn-lg" ">Log Out</a>
</div>
<hr/>
<h1 style="text-align: center">WELCOME TO</h1>
<p style="text-align: center; font-size: 200px">USERS PAGE</p>

