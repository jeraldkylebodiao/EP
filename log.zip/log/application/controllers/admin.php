<?php  
 defined('BASEPATH') OR exit('No direct script access allowed');  
 class Admin extends CI_Controller {  

 	public function index(){
 		$user_role_id = $this->session->userdata('user_role_id');
 		if(!($user_role_id))
 		{
 			echo "walang laman to teh";
 		}
 		elseif ($user_role_id != '1') {
 			$this->load->view('header');
	 		$this->load->view('users');
	 		$this->load->view('footer');
 		}
 		else{
	 		$this->load->view('header');
	 		$this->load->view('admin');
	 		$this->load->view('footer');
 		}
 	}

 }
 ?>