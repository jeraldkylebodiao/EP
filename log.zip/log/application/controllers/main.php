 <?php  
 defined('BASEPATH') OR exit('No direct script access allowed');  
 class Main extends CI_Controller {  
      //functions  

      function __construct(){
        parent:: __construct();
        $this->load->model('main_model', 'm');
      }
      public function login()  
      {  
           //http://localhost/tutorial/codeigniter/main/login  
   
         
           $this->load->view("login"); 
          
      }  
      public function signup()  
      {  
           //http://localhost/tutorial/codeigniter/main/login  
     
           $this->load->view("header");
           $this->load->view("signup"); 
           $this->load->view("footer"); 
      }
      public function login_validation()  
      {  
           $this->load->library('form_validation');  
           $this->form_validation->set_rules('email', 'Email', 'required');  
           $this->form_validation->set_rules('password', 'Password', 'required');  
           if($this->form_validation->run())  
           {    
                $this->load->model('main_model');
                //true  
                $email = $this->input->post('email');  
                $password = $this->input->post('password');  
                //$user_role_id = $this->input->post('user_role_id');
                //model function    $userroleid = $this->user_model->get_user_id();
                $user_role_id= $this->input->post('user_role_id');
                //$user_role_id = $this->main_model->get_user_id();
                $user = $this->main_model->can_login($email, $password, $user_role_id);

                if ($user) {
                   
                //if($this->main_model->can_login($email, $password))  
                //{  
                     $session_data = array(  
                          'email'     =>     $email,
                          'password'     =>  $password,
                          'user_role_id' =>  $user_role_id
                    );  
                     $this->session->set_userdata($session_data);  
                     redirect(base_url() . 'main/enter'); 
                     //return redirect('admin'); 

                }  
                     
                else  
                {  
                     $this->session->set_flashdata('error', 'Invalid Username or Password');  

                     redirect(base_url());  
                }  
           }  
           else  
           {  
                //false  
                $this->login();  
           }  
      }  

      public function submit(){
       $result = $this->m->submit();
        
        if($result){
       
          $this->session->set_flashdata('success_msg', 'Registered successfully.');
        }else{
        
          $this->session->set_flashdata('error_msg', 'Registration failed!');
        }
        redirect(base_url());
      }
     
      public function enter(){   
           $users = $this->session->userdata('user_role_id');
            if(!($users))
              {
                echo "walang laman to teh";
                print_r($users);
               
              }
            elseif ($users != "1") 
           {  
                 $this->load->view("header");
                 $this->load->view("users");
                 $this->load->view("footer");
                 
               
           }  
           else  
           {      
                 
                  $this->load->view("header");
                  $this->load->view("admin"); 
                  $this->load->view("footer");
           }  
      }  
      public function logout()  
      {  
           $this->session->unset_userdata('username');  
           redirect(base_url());  
      }  
 }