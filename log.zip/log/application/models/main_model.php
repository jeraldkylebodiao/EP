 <?php  
 class Main_model extends CI_Model  
 {  
      public function can_login($email, $password)  
      {  
           $this->db->where('email', $email);  
           $this->db->where('password', $password); 
           $query = $this->db->get('users');  
           //SELECT * FROM users WHERE email = '$email' AND password = '$password'  
           if($query->num_rows() > 0)  
           {  
                return true;  
           }  
           else  
           {  
                return false;       
           }  
      } 
      public function get_user_id(){
         $user_role_id = $this->input->post('user_role_id');
      }
      public function submit(){
        $field = array(
          'username'=>$this->input->post('username'),
          'email'=>$this->input->post('email'),
          'password'=>$this->input->post('password'),
          'user_role_id'=>$this->input->post('user_role_id'),
        
       );
        $this->db->insert('users', $field);
        if($this->db->affected_rows() > 0){
          return true;
        }
        else{
          return false;
        }
     }
 }  