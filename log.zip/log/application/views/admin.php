<br/><br/>
<h1 style="text-align: center">WELCOME TO</h1>
<p style="text-align: center; font-size: 200px">ADMINS PAGE</p>
<a href="<?php echo base_url().'main/logout'; ?>" class="btn btn-success btn-lg" style="margin-left: 650px;">Log Out</a>